/**
 * Architecture Floor Plan — Sign Takeoff & PDF Annotator (TypeScript)
 * =====================================================================
 * Extracts all rooms/spaces from an architectural PDF floor plan,
 * generates an Excel sign takeoff sheet, and overlays color-coded
 * dot markers on the original PDF.
 *
 * Tested on: Union at Tower District — 4th Floor Plan (Sheet A1.4)
 * Architect: BVH Architecture | Date: 03-28-2025
 *
 * Dependencies:
 *   npm install pdf-lib pdfjs-dist exceljs
 *   npm install --save-dev @types/node tsx
 *
 * Usage:
 *   npx tsx sign_takeoff_annotator.ts
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * Key Problem Solved — PDF Rotation + Coordinate Transform
 * ─────────────────────────────────────────────────────────────────────────────
 * Architectural PDFs are frequently stored in portrait orientation (raw
 * MediaBox) with a /Rotate metadata flag that tells the viewer to display
 * them in landscape. This creates a mismatch between:
 *
 *   1. pdfjs-dist coordinate space  — works in the DISPLAY (rotated) space.
 *                                      Origin = bottom-left of the display page.
 *                                      y increases UPWARD (unlike pdfplumber).
 *                                      Reports page as e.g. 3024 wide × 2160 tall.
 *
 *   2. pdf-lib draw space           — draws in the RAW (unrotated) space.
 *                                      Origin = bottom-left of the raw MediaBox.
 *                                      y increases UPWARD.
 *                                      Must use raw MediaBox e.g. 2160 wide × 3024 tall.
 *
 * For a page with /Rotate = 90 (viewer rotates 90° CCW to display):
 *
 *        canvas_x = pdfjs_y                ← NOT (raw_width  - pdfjs_y)
 *        canvas_y = pdfjs_x                ← NOT (raw_height - pdfjs_x)
 *
 *   NOTE: pdfjs-dist returns y from the BOTTOM of the display page,
 *   so no top→bottom flip is needed (unlike pdfplumber which is top-down).
 *
 * Generalised transforms for all /Rotate values:
 *   /Rotate = 0:    canvas_x = pdfjs_x,           canvas_y = pdfjs_y
 *   /Rotate = 90:   canvas_x = pdfjs_y,            canvas_y = pdfjs_x
 *   /Rotate = 180:  canvas_x = raw_w - pdfjs_x,   canvas_y = raw_h - pdfjs_y
 *   /Rotate = 270:  canvas_x = raw_h - pdfjs_y,   canvas_y = raw_w - pdfjs_x
 *
 * How to detect this situation:
 *   const pdfDoc   = await PDFDocument.load(bytes);       // pdf-lib
 *   const page     = pdfDoc.getPages()[0];
 *   const rotation = page.getRotation().angle;            // 0 | 90 | 180 | 270
 *   const { width: raw_w, height: raw_h } = page.getSize(); // raw MediaBox
 */

import * as fs from "fs";
import * as path from "path";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.js";
import ExcelJS from "exceljs";

// ── Configuration ─────────────────────────────────────────────────────────────

const INPUT_PDF  = "4th_Floor_Union_at_Tower_Dist.pdf";
const OUTPUT_PDF = "4th_Floor_Annotated_Signs.pdf";
const OUTPUT_XLS = "sign_takeoff.xlsx";

// ── Types ─────────────────────────────────────────────────────────────────────

interface WordItem {
  text: string;
  x: number; // centre x in display space (pdfjs, bottom-left origin)
  y: number; // centre y in display space (pdfjs, bottom-left origin)
}

interface RoomEntry {
  room: string;
  type: string;
  bldg: "A" | "B";
  x: number;
  y: number;
}

type CanvasTransform = (x: number, y: number) => [number, number];

// ── Step 1: Detect page rotation and set up coordinate transform ──────────────

interface PageInfo {
  rawW: number;
  rawH: number;
  rotation: number;
}

async function getPageInfo(pdfPath: string): Promise<PageInfo> {
  const bytes   = fs.readFileSync(pdfPath);
  const pdfDoc  = await PDFDocument.load(bytes);
  const page    = pdfDoc.getPages()[0];
  const { width: rawW, height: rawH } = page.getSize();
  const rotation = page.getRotation().angle; // 0 | 90 | 180 | 270
  return { rawW, rawH, rotation };
}

/**
 * Returns a function that maps pdfjs display coords → pdf-lib raw canvas coords.
 * pdfjs-dist uses bottom-left origin with y increasing upward (same as pdf-lib),
 * so unlike Python/pdfplumber there is no top→bottom flip needed.
 */
function makeCanvasTransform(rawW: number, rawH: number, rotation: number): CanvasTransform {
  const transforms: Record<number, CanvasTransform> = {
      0: (x, y) => [x,          y         ],
     90: (x, y) => [y,          x         ],
    180: (x, y) => [rawW - x,   rawH - y  ],
    270: (x, y) => [rawH - y,   rawW - x  ],
  };
  const fn = transforms[rotation];
  if (!fn) throw new Error(`Unsupported rotation: ${rotation}`);
  return fn;
}

// ── Step 2: Extract text words from PDF via pdfjs-dist ────────────────────────

/**
 * pdfjs-dist returns text items with a `transform` matrix [a,b,c,d,e,f]
 * where (e, f) is the bottom-left origin position of the text in display space.
 * We approximate the word centre as (e + width/2, f + height/2).
 *
 * NOTE: pdfjs-dist automatically applies /Rotate so coordinates are already
 * in display (viewer) space — which is what we want before applying our transform.
 */
async function extractWords(pdfPath: string): Promise<WordItem[]> {
  const data     = new Uint8Array(fs.readFileSync(pdfPath));
  const loadTask = pdfjsLib.getDocument({ data, useSystemFonts: true });
  const pdf      = await loadTask.promise;
  const page     = await pdf.getPage(1);
  const content  = await page.getTextContent();

  const items: WordItem[] = [];
  for (const item of content.items) {
    if (!("str" in item) || !item.str.trim()) continue;
    const [, , , , tx, ty] = item.transform as number[];
    const w = item.width  as number;
    const h = item.height as number;
    items.push({
      text: item.str.trim(),
      x: tx + w / 2,
      y: ty + h / 2,
    });
  }
  return items;
}

// ── Step 3: Parse rooms and spaces ───────────────────────────────────────────

const ROOM_NUM_RE   = /^\d{3}[AB]$/;
const UNIT_TYPE_RE  = /^[123][AB]$/;
const SERVICE_ID_RE = /^[AB]\d{3}$|^[AB]E-\d$|^[AB]S[12]-\d$/;

const SERVICE_LABEL_MAP: Record<string, string> = {
  A401: "LOBBY",       B401: "LOBBY",
  A402: "CORR",        B402: "CORR",
  A403: "ELEC",        B403: "ELEC",
  A404: "ELEC",        B404: "ELEC",
  A405: "MECH",        B405: "MECH",
  A406: "ELEC",        B406: "ELEC",
  A407: "MECH",        B407: "MECH",
  A408: "ELEV EQUIP",  B408: "ELEV EQUIP",
  A409: "TENANT STOR", B409: "TENANT STOR",
  "AE-4":  "ELEV",    "BE-4":  "ELEV",
  "AS1-4": "STAIR",   "AS2-4": "STAIR",
  "BS1-4": "STAIR",   "BS2-4": "STAIR",
};

function extractRooms(items: WordItem[]): RoomEntry[] {
  const results: RoomEntry[] = [];

  // ── Residential units ──────────────────────────────────────────────────────
  for (const room of items.filter(i => ROOM_NUM_RE.test(i.text))) {
    const { x: rx, y: ry } = room;
    let unitLabel: string | null = null;

    // "UNIT" label sits just above/near the room number in the same column
    for (const item of items) {
      if (
        item.text === "UNIT" &&
        Math.abs(item.x - rx) < 40 &&
        Math.abs(item.y - ry) < 30
      ) {
        // Unit type (1A, 2B, …) is on the same line as "UNIT", slightly right
        for (const t of items) {
          if (
            UNIT_TYPE_RE.test(t.text) &&
            Math.abs(t.x - item.x) < 50 &&
            Math.abs(t.y - item.y) < 5
          ) {
            unitLabel = t.text;
            break;
          }
        }
        break;
      }
    }

    const bldg = room.text.endsWith("A") ? "A" : "B";
    results.push({
      room: room.text,
      type: unitLabel ? `UNIT ${unitLabel}` : "UNIT",
      bldg,
      x: rx,
      y: ry,
    });
  }

  // ── Service / support spaces ───────────────────────────────────────────────
  for (const sid of items.filter(i => SERVICE_ID_RE.test(i.text))) {
    const bldg = sid.text[0] === "A" ? "A" : "B";
    const stype = SERVICE_LABEL_MAP[sid.text] ?? "SERVICE";
    results.push({ room: sid.text, type: stype, bldg, x: sid.x, y: sid.y });
  }

  results.sort((a, b) =>
    a.bldg.localeCompare(b.bldg) || a.room.localeCompare(b.room)
  );
  return results;
}

// ── Step 4: Sign type classification ─────────────────────────────────────────

function classifySign(roomId: string, roomType: string): [string, string] {
  const rt  = roomType.toUpperCase();
  const rid = roomId.toUpperCase();

  if (rt.includes("UNIT")) {
    const ut = rt.replace("UNIT ", "");
    const beds: Record<string, string> = {
      "1A": "1-BED", "1B": "1-BED",
      "2A": "2-BED", "2B": "2-BED",
      "3A": "3-BED", "3B": "3-BED",
    };
    return [`${beds[ut] ?? ""} UNIT SIGN`, "Suite ID Sign"];
  }
  if (rt.includes("LOBBY"))       return ["LOBBY SIGN",           "Directory / Lobby ID Sign"];
  if (rt.includes("MECH"))        return ["MECHANICAL ROOM SIGN", "Hazard / ID Sign"];
  if (rt.includes("ELEC"))        return ["ELECTRICAL ROOM SIGN", "Hazard / ID Sign"];
  if (rt.includes("STAIR") || /^[AB]S/.test(rid))
                                   return ["STAIRWELL SIGN",       "Egress Sign"];
  if (rt.includes("ELEV EQUIP"))  return ["ELEV EQUIPMENT SIGN",  "Elevator ID Sign"];
  if (rt.includes("ELEV"))        return ["ELEVATOR SIGN",         "Elevator ID Sign"];
  if (rt.includes("TENANT STOR")) return ["TENANT STORAGE SIGN",  "Room ID Sign"];
  if (rt.includes("CORR"))        return ["CORRIDOR SIGN",         "Wayfinding Sign"];
  return ["ROOM ID SIGN", "Room ID Sign"];
}

// ── Step 5: Build Excel sign takeoff ──────────────────────────────────────────

async function buildExcel(rooms: RoomEntry[], outputPath: string): Promise<void> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("4th Floor Sign Takeoff");

  // Helpers
  const hdrFill  = (color: string) => ({ type: "pattern" as const, pattern: "solid" as const, fgColor: { argb: color } });
  const hdrFont  = (sz = 10, color = "FFFFFFFF"): Partial<ExcelJS.Font> => ({ name: "Arial", bold: true, size: sz, color: { argb: color } });
  const cellFont = (bold = false, sz = 9): Partial<ExcelJS.Font> => ({ name: "Arial", bold, size: sz, color: { argb: "FF1A1A1A" } });
  const ctr: Partial<ExcelJS.Alignment> = { horizontal: "center", vertical: "middle", wrapText: true };
  const lft: Partial<ExcelJS.Alignment> = { horizontal: "left",   vertical: "middle", wrapText: true };
  const thin  = { style: "thin"   as const, color: { argb: "FFAAAAAA" } };
  const medBorder = { style: "medium" as const, color: { argb: "FF333333" } };
  const bdr = { top: thin, bottom: thin, left: thin, right: thin };

  const FILL_HDR  = "FF1F3864";
  const FILL_SUB  = "FF2E75B6";
  const FILL_TOT  = "FFE2EFDA";
  const FILL_A    = ["FFDDEEFF", "FFEEF5FF"];
  const FILL_B    = ["FFFFF2CC", "FFFFFAE8"];

  // Title rows
  ws.mergeCells("A1:H1");
  const t1 = ws.getCell("A1");
  t1.value = "UNION AT TOWER DISTRICT — 4TH FLOOR SIGN TAKEOFF";
  t1.font = hdrFont(14); t1.fill = hdrFill(FILL_HDR);
  t1.alignment = ctr; t1.border = bdr;
  ws.getRow(1).height = 28;

  ws.mergeCells("A2:H2");
  const t2 = ws.getCell("A2");
  t2.value = "Project: Union at Tower District  |  Sheet: A1.4  |  Date: 03-28-2025  |  Architect: BVH Architecture";
  t2.font = { name: "Arial", size: 9, color: { argb: "FFFFFFFF" }, italic: true };
  t2.fill = hdrFill(FILL_SUB); t2.alignment = ctr; t2.border = bdr;
  ws.getRow(2).height = 18;
  ws.addRow([]); ws.getRow(3).height = 6;

  // Column headers
  const COLS = ["#", "BUILDING", "ROOM / SPACE ID", "UNIT TYPE", "SIGN TYPE", "SIGN DESCRIPTION", "QTY", "NOTES"];
  const hRow = ws.addRow(COLS);
  hRow.height = 22;
  hRow.eachCell(cell => {
    cell.font = hdrFont(); cell.fill = hdrFill(FILL_SUB);
    cell.alignment = ctr; cell.border = bdr;
  });

  const dataStart = ws.rowCount + 1;
  const summary: Record<string, number> = {};

  rooms.forEach((r, idx) => {
    const [stype, sdesc] = classifySign(r.room, r.type);
    const fills = r.bldg === "A" ? FILL_A : FILL_B;
    const fill  = fills[(idx + 1) % 2];
    const row   = ws.addRow([idx + 1, `Building ${r.bldg}`, r.room, r.type, stype, sdesc, 1, ""]);
    row.height  = 18;
    row.eachCell((cell, colNum) => {
      cell.fill      = hdrFill(fill);
      cell.border    = bdr;
      cell.font      = cellFont();
      cell.alignment = [1, 2, 7].includes(colNum) ? ctr : lft;
    });
    summary[stype] = (summary[stype] ?? 0) + 1;
  });

  const dataEnd = ws.rowCount;

  // Totals
  ws.addRow([]);
  const totRow = ws.addRow(["TOTAL", "", "", "", "ALL SIGNS", "", { formula: `SUM(G${dataStart}:G${dataEnd})` }, ""]);
  totRow.height = 22;
  totRow.eachCell(cell => {
    cell.fill      = hdrFill(FILL_TOT);
    cell.font      = { name: "Arial", bold: true, size: 10 };
    cell.alignment = ctr;
    cell.border    = { top: medBorder, bottom: medBorder, left: thin, right: thin };
  });

  // Column widths
  [5, 14, 16, 14, 28, 26, 7, 20].forEach((w, i) => {
    ws.getColumn(i + 1).width = w;
  });

  // Summary sheet
  const ws2 = wb.addWorksheet("Sign Type Summary");
  ws2.mergeCells("A1:D1");
  const s1 = ws2.getCell("A1");
  s1.value = "SIGN TYPE SUMMARY — 4TH FLOOR";
  s1.font = hdrFont(13); s1.fill = hdrFill(FILL_HDR);
  s1.alignment = ctr; s1.border = bdr;
  ws2.getRow(1).height = 26;
  ws2.addRow([]);
  const sh = ws2.addRow(["SIGN TYPE", "SIGN DESCRIPTION", "COUNT", "NOTES"]);
  sh.height = 20;
  sh.eachCell(cell => { cell.font = hdrFont(); cell.fill = hdrFill(FILL_SUB); cell.alignment = ctr; cell.border = bdr; });

  Object.entries(summary).sort().forEach(([stype, count], i) => {
    const [, desc] = classifySign("", stype.split(" ")[0]);
    const row = ws2.addRow([stype, desc, count, ""]);
    row.height = 18;
    row.eachCell((cell, col) => {
      cell.fill      = hdrFill(FILL_A[i % 2]);
      cell.font      = cellFont();
      cell.alignment = col === 3 ? ctr : lft;
      cell.border    = bdr;
    });
  });

  const tot2 = ws2.addRow(["TOTAL", "", { formula: `SUM(C4:C${ws2.rowCount})` }, ""]);
  tot2.height = 22;
  tot2.eachCell(cell => {
    cell.fill = hdrFill(FILL_TOT);
    cell.font = { name: "Arial", bold: true, size: 10 };
    cell.alignment = ctr;
    cell.border = { top: medBorder, bottom: medBorder, left: thin, right: thin };
  });
  [32, 26, 10, 22].forEach((w, i) => { ws2.getColumn(i + 1).width = w; });

  await wb.xlsx.writeFile(outputPath);
  console.log(`✓ Excel saved → ${outputPath}  (${rooms.length} signs, ${Object.keys(summary).length} types)`);
}

// ── Step 6: Build annotated PDF with color-coded dot markers ─────────────────

// Colors keyed by unit sub-type or space type
const COLOR_MAP: Record<string, [number, number, number]> = {
  "1A": [0.129, 0.588, 0.953], // blue
  "1B": [0.086, 0.396, 0.753], // dark blue
  "2A": [0.298, 0.686, 0.314], // green
  "2B": [0.180, 0.490, 0.196], // dark green
  "3A": [1.000, 0.596, 0.000], // orange
  "3B": [0.902, 0.318, 0.000], // dark orange
  "LOBBY":       [0.612, 0.153, 0.690], // purple
  "MECH":        [0.957, 0.263, 0.212], // red
  "ELEC":        [1.000, 0.341, 0.133], // deep orange
  "STAIR":       [0.376, 0.490, 0.545], // blue-grey
  "ELEV":        [0.000, 0.737, 0.831], // cyan
  "ELEV EQUIP":  [0.000, 0.675, 0.757], // teal
  "TENANT STOR": [0.475, 0.333, 0.282], // brown
  "CORR":        [0.620, 0.620, 0.620], // grey
};

const LEGEND_LABELS: Array<[string, string]> = [
  ["1-BED UNIT (1A)", "1A"],  ["1-BED UNIT (1B)", "1B"],
  ["2-BED UNIT (2A)", "2A"],  ["2-BED UNIT (2B)", "2B"],
  ["3-BED UNIT (3A)", "3A"],  ["3-BED UNIT (3B)", "3B"],
  ["LOBBY",           "LOBBY"],
  ["MECHANICAL ROOM", "MECH"],
  ["ELECTRICAL ROOM", "ELEC"],
  ["STAIRWELL",       "STAIR"],
  ["ELEVATOR",        "ELEV"],
  ["ELEV EQUIP ROOM", "ELEV EQUIP"],
  ["TENANT STORAGE",  "TENANT STOR"],
  ["CORRIDOR",        "CORR"],
];

function getRoomColor(roomType: string): [number, number, number] {
  const rt = roomType.toUpperCase();
  if (rt.includes("UNIT")) {
    const key = rt.replace("UNIT ", "");
    return COLOR_MAP[key] ?? COLOR_MAP["1A"];
  }
  for (const [key, val] of Object.entries(COLOR_MAP)) {
    if (rt.includes(key)) return val;
  }
  return [0.6, 0.6, 0.6];
}

async function buildAnnotatedPdf(
  rooms: RoomEntry[],
  inputPath: string,
  outputPath: string,
  toCanvas: CanvasTransform,
  rawW: number,
  rawH: number,
): Promise<void> {
  const existingBytes = fs.readFileSync(inputPath);
  const pdfDoc = await PDFDocument.load(existingBytes);
  const page   = pdfDoc.getPages()[0];

  // pdf-lib draws in raw MediaBox space (bottom-left origin, y up)
  // We must override the page size to raw dimensions before drawing,
  // then restore the rotation so the viewer still displays it correctly.
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const DOT_R = 8;

  // Draw dot markers
  for (const r of rooms) {
    const [cx, cy] = toCanvas(r.x, r.y);
    const [red, green, blue] = getRoomColor(r.type);

    // White outline circle (slightly larger)
    page.drawCircle({
      x: cx, y: cy, size: DOT_R + 1.5,
      borderColor: rgb(1, 1, 1),
      borderWidth: 1.5,
      color: rgb(red, green, blue),
    });
  }

  // ── Legend ────────────────────────────────────────────────────────────────
  // Place legend at raw bottom-left (low raw_x, low raw_y).
  // For /Rotate=90, this appears at the bottom-right of the displayed page.
  const LEG_X   = 30;
  const LEG_Y   = 30;
  const LEG_W   = 260;
  const ITEM_H  = 17;
  const LEG_H   = LEGEND_LABELS.length * ITEM_H + 28;

  // Background
  page.drawRectangle({
    x: LEG_X - 6, y: LEG_Y - 4,
    width: LEG_W, height: LEG_H,
    color: rgb(1, 1, 1),
    borderColor: rgb(0.2, 0.2, 0.2),
    borderWidth: 1,
  });

  // Header bar
  page.drawRectangle({
    x: LEG_X - 6, y: LEG_Y + LEG_H - 22,
    width: LEG_W, height: 22,
    color: rgb(0.122, 0.220, 0.392), // #1F3864
  });
  page.drawText("SIGN LEGEND — 4TH FLOOR", {
    x: LEG_X, y: LEG_Y + LEG_H - 16,
    size: 8, font: fontBold, color: rgb(1, 1, 1),
  });

  // Legend items
  LEGEND_LABELS.forEach(([label, key], i) => {
    const iy = LEG_Y + LEG_H - 38 - i * ITEM_H;
    const [r, g, b] = COLOR_MAP[key] ?? [0.6, 0.6, 0.6];

    // Dot
    page.drawCircle({
      x: LEG_X + 6, y: iy + 4, size: 6,
      color: rgb(r, g, b),
      borderColor: rgb(1, 1, 1),
      borderWidth: 0.5,
    });

    // Label
    page.drawText(label, {
      x: LEG_X + 18, y: iy + 1,
      size: 7, font, color: rgb(0.1, 0.1, 0.1),
    });
  });

  const pdfBytes = await pdfDoc.save();
  fs.writeFileSync(outputPath, pdfBytes);
  console.log(`✓ Annotated PDF saved → ${outputPath}  (${rooms.length} markers)`);
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main(): Promise<void> {
  console.log(`\nProcessing: ${INPUT_PDF}`);

  const { rawW, rawH, rotation } = await getPageInfo(INPUT_PDF);
  console.log(`  Raw MediaBox : ${rawW} × ${rawH} pts`);
  console.log(`  /Rotate      : ${rotation}°`);

  const toCanvas = makeCanvasTransform(rawW, rawH, rotation);

  const words = await extractWords(INPUT_PDF);
  console.log(`  Words found  : ${words.length}`);

  const rooms = extractRooms(words);
  console.log(`  Rooms found  : ${rooms.length}`);

  await buildExcel(rooms, OUTPUT_XLS);
  await buildAnnotatedPdf(rooms, INPUT_PDF, OUTPUT_PDF, toCanvas, rawW, rawH);

  console.log("\nDone.");
}

main().catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
