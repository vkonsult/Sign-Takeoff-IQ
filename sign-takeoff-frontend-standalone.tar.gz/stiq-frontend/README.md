# Sign TakeOff IQ — Frontend

A standalone React + Vite frontend for the Sign TakeOff IQ app.
All Clerk auth and workspace dependencies have been removed and replaced
with simple, swappable equivalents.

## Quick Start

```bash
npm install
npm run dev
```

## Configuration

Create a `.env` file in the project root:

```env
# Point this at your backend API server
VITE_API_BASE_URL=http://localhost:8080

# Optional: a guest token that bypasses auth (for demos)
VITE_GUEST_TOKEN=your-guest-token
```

## Wiring Up Your Own Auth

All auth logic lives in **`src/lib/authContext.tsx`**.

Open that file and replace the hardcoded user inside `AuthProvider` with
your real auth — for example, decoding a JWT from localStorage, calling a
`/api/me` endpoint, or integrating any OAuth library.

The shape returned must match:

```ts
{
  isSignedIn: boolean;
  isLoaded: boolean;
  user: {
    id: string;
    publicMetadata: {
      role?: "SUPER_ADMIN" | "ADMIN" | "ESTIMATOR" | "PROJECT_MANAGER" | "SALES";
      organizationId?: string;
    };
  } | null;
  signOut: () => void;
}
```

## Wiring Up Your API

All API calls use `apiFetch()` from **`src/lib/apiClient.ts`**, which
automatically prepends `VITE_API_BASE_URL` to every request.

The generated API hook types (React Query) live in
**`src/lib/generated/api.ts`** — replace these with your own hooks or
keep them and point the base URL at your backend.

## Tech Stack

- React 19 + Vite
- Tailwind CSS v4 + shadcn/ui
- TanStack Query (React Query)
- Wouter (routing)
- Lucide icons
- react-pdf / pdf-lib (PDF rendering)
