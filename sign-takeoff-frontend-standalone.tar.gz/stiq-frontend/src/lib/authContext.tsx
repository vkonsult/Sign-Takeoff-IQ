/**
 * Simple auth context — replace the value inside AuthProvider with your
 * own authentication logic (JWT decode, session cookie, OAuth, etc.)
 *
 * Roles: SUPER_ADMIN | ADMIN | ESTIMATOR | PROJECT_MANAGER | SALES
 */
import { createContext, useContext, ReactNode } from "react";

export interface AuthUser {
  id: string;
  publicMetadata: {
    role?: string;
    organizationId?: string;
  };
}

interface AuthContextValue {
  isSignedIn: boolean;
  isLoaded: boolean;
  user: AuthUser | null;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue>({
  isSignedIn: true,
  isLoaded: true,
  user: { id: "user-1", publicMetadata: { role: "SUPER_ADMIN", organizationId: "org-1" } },
  signOut: () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  // TODO: Replace this with your real auth logic.
  // Example: read a JWT from localStorage, call your /api/me endpoint, etc.
  const value: AuthContextValue = {
    isSignedIn: true,
    isLoaded: true,
    user: {
      id: "user-1",
      publicMetadata: {
        role: "SUPER_ADMIN",
        organizationId: "org-1",
      },
    },
    signOut: () => {
      // TODO: clear session / token and redirect to login
      window.location.href = "/sign-in";
    },
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  return useContext(AuthContext);
}
