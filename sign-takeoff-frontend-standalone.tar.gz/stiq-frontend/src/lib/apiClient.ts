/**
 * API client — set VITE_API_BASE_URL in your .env to point at your backend.
 * e.g. VITE_API_BASE_URL=https://your-api.example.com
 */
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? "";

const GUEST_TOKEN_KEY = "sign_iq_guest_token";

export function setGuestToken(token: string) {
  sessionStorage.setItem(GUEST_TOKEN_KEY, token);
}

export function clearGuestToken() {
  sessionStorage.removeItem(GUEST_TOKEN_KEY);
}

export function getGuestToken(): string | null {
  return sessionStorage.getItem(GUEST_TOKEN_KEY);
}

export function isGuestMode(): boolean {
  return !!getGuestToken();
}

/** Resolves a relative API path against VITE_API_BASE_URL */
function resolveUrl(input: RequestInfo | URL): RequestInfo | URL {
  if (!API_BASE_URL) return input;
  if (typeof input === "string" && input.startsWith("/")) {
    return `${API_BASE_URL}${input}`;
  }
  return input;
}

export async function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const url = resolveUrl(input);
  const guestToken = getGuestToken();
  if (guestToken) {
    const headers = new Headers(init?.headers);
    if (!headers.has("Authorization")) {
      headers.set("Authorization", `Bearer ${guestToken}`);
    }
    return fetch(url, { ...init, headers });
  }
  return fetch(url, init);
}

export async function openPdfInNewTab(jobId: string, fileId: string, originalName: string, page?: number): Promise<void> {
  const res = await apiFetch(`/api/jobs/${jobId}/files/${fileId}/pdf`);
  if (!res.ok) throw new Error(`Failed to load PDF: ${res.status}`);
  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);
  const url = page != null ? `${blobUrl}#page=${page}` : blobUrl;
  const win = window.open(url, "_blank");
  if (!win) {
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.download = originalName;
    a.click();
  }
  setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
}
