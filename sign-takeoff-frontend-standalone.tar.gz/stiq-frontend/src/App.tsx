import { Switch, Route, Redirect, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/authContext";

import Home from "@/pages/Home";
import LandingPage from "@/pages/LandingPage";
import JobsList from "@/pages/JobsList";
import JobDetails from "@/pages/JobDetails";
import Training from "@/pages/Training";
import NotFound from "@/pages/not-found";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminOrgs from "@/pages/AdminOrgs";
import AdminUsers from "@/pages/AdminUsers";
import AdminVocabulary from "@/pages/AdminVocabulary";
import OnboardingPage from "@/pages/OnboardingPage";
import SettingsCompany from "@/pages/SettingsCompany";
import SettingsUsers from "@/pages/SettingsUsers";
import ActivityPage from "@/pages/ActivityPage";
import { useUserRole } from "@/hooks/use-user-role";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error) => {
        if ((error as { status?: number })?.status === 404) return false;
        return failureCount < 3;
      },
    },
  },
});

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isSignedIn } = useAuth();
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  return <Component />;
}

function AdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { isSignedIn, isLoaded, isAdmin } = useUserRole();
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  if (!isLoaded) return null;
  if (!isAdmin) return <Redirect to="/jobs" />;
  return <Component />;
}

function SuperAdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { isSignedIn, isLoaded, isSuperAdmin } = useUserRole();
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  if (!isLoaded) return null;
  if (!isSuperAdmin) return <Redirect to="/jobs" />;
  return <Component />;
}

function SignInPage() {
  const { isSignedIn } = useAuth();
  if (isSignedIn) return <Redirect to="/jobs" />;
  // TODO: Replace with your own sign-in UI
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <p className="text-muted-foreground">Sign-in page — wire up your auth here.</p>
    </div>
  );
}

function HomeRoute() {
  const { isSignedIn } = useAuth();
  if (isSignedIn) return <Redirect to="/jobs" />;
  return <LandingPage />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeRoute} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/onboarding">{() => <ProtectedRoute component={OnboardingPage} />}</Route>
      <Route path="/new-upload">{() => <ProtectedRoute component={Home} />}</Route>
      <Route path="/jobs">{() => <ProtectedRoute component={JobsList} />}</Route>
      <Route path="/jobs/:jobId">{() => <ProtectedRoute component={JobDetails} />}</Route>
      <Route path="/training">{() => <ProtectedRoute component={Training} />}</Route>
      <Route path="/activity">{() => <ProtectedRoute component={ActivityPage} />}</Route>
      <Route path="/settings">{() => <AdminRoute component={SettingsCompany} />}</Route>
      <Route path="/settings/users">{() => <AdminRoute component={SettingsUsers} />}</Route>
      <Route path="/admin">{() => <SuperAdminRoute component={AdminDashboard} />}</Route>
      <Route path="/admin/organizations">{() => <SuperAdminRoute component={AdminOrgs} />}</Route>
      <Route path="/admin/users">{() => <SuperAdminRoute component={AdminUsers} />}</Route>
      <Route path="/admin/vocabulary">{() => <SuperAdminRoute component={AdminVocabulary} />}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <AuthProvider>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <Router />
            <Toaster />
          </TooltipProvider>
        </QueryClientProvider>
      </AuthProvider>
    </WouterRouter>
  );
}

export default App;
