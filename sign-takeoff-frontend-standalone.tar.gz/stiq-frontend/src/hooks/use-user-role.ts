import { useAuth } from "@/lib/authContext";

export type AppRole =
  | "SUPER_ADMIN"
  | "ADMIN"
  | "SALES"
  | "ESTIMATOR"
  | "PROJECT_MANAGER"
  | "GUEST";

export function useUserRole(): {
  role: AppRole;
  organizationId: string | null;
  isLoaded: boolean;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isSignedIn: boolean;
} {
  const { user, isLoaded, isSignedIn } = useAuth();

  const meta = (user?.publicMetadata ?? {}) as {
    role?: string;
    organizationId?: string;
  };

  const rawRole = meta.role ?? "ESTIMATOR";
  const validRoles: AppRole[] = [
    "SUPER_ADMIN",
    "ADMIN",
    "SALES",
    "ESTIMATOR",
    "PROJECT_MANAGER",
  ];
  const role: AppRole = validRoles.includes(rawRole as AppRole)
    ? (rawRole as AppRole)
    : "ESTIMATOR";

  const organizationId = meta.organizationId ?? null;

  return {
    role,
    organizationId,
    isLoaded,
    isSignedIn,
    isSuperAdmin: role === "SUPER_ADMIN",
    isAdmin: role === "ADMIN" || role === "SUPER_ADMIN",
  };
}
